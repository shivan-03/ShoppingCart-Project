/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shoppingjunction;
import ShoppingPackage.ProductCatalog;
import ShoppingPackage.ShoppingCart;
import ShoppingPackage.SellerFrame;
import ShoppingPackage.CustomerFrame;
import ShoppingPackage.LoginStrategy;
import ShoppingPackage.AuthenticationManager;
import ShoppingPackage.SimpleAuthStrategy;
import ShoppingPackage.LoginFrame;
import ShoppingPackage.LoginListener;

/**
 * Main application class that initializes and runs the shopping system.
 * This class integrates login functionality with the seller and customer interfaces.
 *
 * Author: Shivan, Jaali
 */
public class MainApp {
    
    /**
     * The main method that serves as the entry point of the application.
     * It sets up the login process, handles authentication, and displays the product catalog,
     * shopping cart, and the corresponding frames for the seller and customer.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        // Step 1: Set up authentication
        LoginStrategy authStrategy = new SimpleAuthStrategy();
        AuthenticationManager authManager = new AuthenticationManager(authStrategy);

        // Step 2: Display the login frame
        LoginFrame loginFrame = new LoginFrame(authManager, new LoginListener() {
            /**
             * Called on successful login to initialize and display the application.
             */
            @Override
            public void onLoginSuccess() {
                System.out.println("Login successful. Initializing the application...");

                // Create a shared ProductCatalog instance
                ProductCatalog sharedProductCatalog = new ProductCatalog();

                // Create a ShoppingCart instance for the customer
                ShoppingCart customerShoppingCart = new ShoppingCart();

                // Initialize and display SellerFrame
                SellerFrame sellerFrame = new SellerFrame(sharedProductCatalog);

                // Initialize and display CustomerFrame
                CustomerFrame customerFrame = new CustomerFrame(sharedProductCatalog, customerShoppingCart);

                // Make frames visible
                sellerFrame.setVisible(true);
                customerFrame.setVisible(true);
            }

            /**
             * Called on login failure to prompt the user to retry.
             */
            @Override
            public void onLoginFailure() {
                System.out.println("Login failed. Please try again.");
            }
        });

        // Make the login frame visible
        loginFrame.setVisible(true);
    }
}

