/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ShoppingPackage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This class represents the login frame where users can input their username and password to log into the application.
 * It uses an AuthenticationManager for login validation and communicates with a LoginListener for handling login success or failure.
 * 
 * Author: Jaali
 */
public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private AuthenticationManager authManager;
    private LoginListener loginListener;

    /**
     * Constructs a LoginFrame with the specified AuthenticationManager and LoginListener.
     *
     * @param authManager the AuthenticationManager responsible for validating user credentials
     * @param listener the LoginListener that handles login success or failure events
     */
    public LoginFrame(AuthenticationManager authManager, LoginListener listener) {
        // Set the title and basic properties
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the frame on the screen

        this.authManager = authManager;
        this.loginListener = listener;  // Set the listener

        // Create UI elements
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));  // Layout with 3 rows and 2 columns

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");

        usernameField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("Login");

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(new JLabel());  // Empty space
        panel.add(loginButton);

        // Add panel to frame
        add(panel);

        // Handle login button click
        loginButton.addActionListener(new ActionListener() {
            /**
             * This method is invoked when the login button is clicked. It retrieves the username and password entered by the user,
             * validates them using the AuthenticationManager, and notifies the LoginListener of the result.
             *
             * @param e the ActionEvent triggered by clicking the login button
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                // Attempt login using AuthenticationManager
                boolean loginSuccess = authManager.login(username, password);

                if (loginSuccess) {
                    loginListener.onLoginSuccess();  // Notify listener on successful login
                    dispose();  // Close the login frame
                } else {
                    loginListener.onLoginFailure();  // Notify listener on failed login
                }
            }
        });
    }
}