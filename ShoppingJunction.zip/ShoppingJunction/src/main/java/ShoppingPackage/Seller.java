/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ShoppingPackage;

/**
 *
 * @author shivan
 */
public class Seller {
    private Inventory inventory;
    private String name;
/**
 * 
 * @param inventory seller's inventory based off of the seller login name
 * @param name name of the seller that also is linked with inventory
 */
    public Seller(Inventory inventory, String name){
        this.inventory = inventory;
        this.name = name;
    }
    public void manageInventory(){
        System.out.println("Managing inventory for " + name);
    }
    public void viewFinancialInfo(){
        System.out.println("Viewing financial info for " + name);
    }
    public Inventory getInventory(){
        return inventory;
    }
/**
 * 
 * @param inventory the inventory that is available for sale from seller
 */
    public void setInventory(Inventory inventory){
        this.inventory = inventory;
    }
    public String getName(){
        return name;
    }
    public void setName(){
        this.name = name;
    }
}