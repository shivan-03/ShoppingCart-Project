/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ShoppingPackage;

import java.util.HashMap;
import java.util.Map;

/**
 * This class implements the {@link LoginStrategy} interface and provides a simple authentication strategy
 * using an in-memory user database. It allows users to log in, log out, and create accounts.
 * 
 * The user database is a HashMap that stores usernames and passwords for authentication purposes.
 * This class is intended for simple testing and educational purposes.
 * 
 * Author: Jaali
 */
public class SimpleAuthStrategy implements LoginStrategy {
    
    // In-memory user database for storing usernames and passwords
    private Map<String, String> userDatabase = new HashMap<>();

    /**
     * Constructor that initializes the SimpleAuthStrategy.
     * A sample user is pre-created for testing purposes with username "user1" and password "password123".
     */
    public SimpleAuthStrategy() {
        // Pre-create a sample user (for testing purposes)
        userDatabase.put("user1", "password123");
    }

    /**
     * Attempts to log in a user by checking the provided username and password against the user database.
     *
     * @param username the username of the user trying to log in
     * @param password the password entered by the user
     * @return true if the login is successful, false otherwise
     */
    @Override
    public boolean login(String username, String password) {
        // Check if username and password match
        if (userDatabase.containsKey(username) && userDatabase.get(username).equals(password)) {
            System.out.println("Login successful for user: " + username);
            return true;
        }
        System.out.println("Login failed for user: " + username);
        return false;
    }

    /**
     * Logs out the user by printing a logout message.
     *
     * @param username the username of the user who is logging out
     * @return true to indicate the logout was successful
     */
    @Override
    public boolean logout(String username) {
        // Log out logic (For simplicity, we just print a message)
        System.out.println("User " + username + " logged out.");
        return true;
    }

    /**
     * Creates a new account by adding the username and password to the user database.
     * If the username already exists, the account creation fails.
     *
     * @param username the username for the new account
     * @param password the password for the new account
     * @return true if the account is successfully created, false if the username already exists
     */
    @Override
    public boolean createAccount(String username, String password) {
        if (userDatabase.containsKey(username)) {
            System.out.println("Account with this username already exists.");
            return false;
        }
        userDatabase.put(username, password);
        System.out.println("Account created successfully for user: " + username);
        return true;
    }
}
