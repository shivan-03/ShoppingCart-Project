/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ShoppingPackage;

/**
 * This interface defines the methods that should be implemented by any class that listens for login events.
 * It provides methods to handle successful and failed login attempts.
 * 
 * Author: Jaali
 */
public interface LoginListener {
    
    /**
     * This method is invoked when a login attempt is successful.
     */
    void onLoginSuccess();

    /**
     * This method is invoked when a login attempt fails.
     */
    void onLoginFailure();
}