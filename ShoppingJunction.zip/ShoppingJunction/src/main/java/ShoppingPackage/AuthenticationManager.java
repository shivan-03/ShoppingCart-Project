/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ShoppingPackage;
/**
 * The AuthenticationManager class is a context class that uses the {@link LoginStrategy} to perform login,
 * logout, and account creation operations. This class allows the dynamic switching of login strategies 
 * at runtime.
 * 
 * It delegates authentication-related tasks to the specific strategy provided, making it flexible to change
 * the authentication mechanism (e.g., SimpleAuth, OAuth, etc.) without modifying the core logic of the application.
 * 
 * Author: Jaali
 */
public class AuthenticationManager {
    
    // The strategy used for handling login, logout, and account creation
    private LoginStrategy loginStrategy;

    /**
     * Constructor that initializes the AuthenticationManager with the specified login strategy.
     * 
     * @param loginStrategy the login strategy to use for authentication tasks
     */
    public AuthenticationManager(LoginStrategy loginStrategy) {
        this.loginStrategy = loginStrategy;
    }

    /**
     * Sets a new login strategy at runtime.
     *
     * @param loginStrategy the new login strategy to be used
     */
    public void setLoginStrategy(LoginStrategy loginStrategy) {
        this.loginStrategy = loginStrategy;
    }

    /**
     * Attempts to log the user in using the current login strategy.
     *
     * @param username the username of the user attempting to log in
     * @param password the password of the user
     * @return true if the login is successful, false otherwise
     */
    public boolean login(String username, String password) {
        return loginStrategy.login(username, password);
    }

    /**
     * Logs the user out using the current login strategy.
     *
     * @param username the username of the user attempting to log out
     * @return true if the logout is successful, false otherwise
     */
    public boolean logout(String username) {
        return loginStrategy.logout(username);
    }

    /**
     * Creates a new account using the current login strategy.
     *
     * @param username the username for the new account
     * @param password the password for the new account
     * @return true if the account is successfully created, false otherwise
     */
    public boolean createAccount(String username, String password) {
        return loginStrategy.createAccount(username, password);
    }
}
