/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ShoppingPackage;


/**
 * This interface defines the strategy for handling login-related operations such as login, logout, and account creation.
 * Classes implementing this interface provide specific implementations of these methods based on different login strategies.
 * 
 * Author: Jaali
 */
public interface LoginStrategy {

    /**
     * Attempts to log the user in with the provided username and password.
     *
     * @param username the username of the user
     * @param password the password of the user
     * @return true if login is successful, false otherwise
     */
    boolean login(String username, String password);

    /**
     * Logs the user out with the specified username.
     *
     * @param username the username of the user to log out
     * @return true if logout is successful, false otherwise
     */
    boolean logout(String username);

    /**
     * Creates a new account with the specified username and password.
     *
     * @param username the username for the new account
     * @param password the password for the new account
     * @return true if account creation is successful, false otherwise
     */
    boolean createAccount(String username, String password);
}