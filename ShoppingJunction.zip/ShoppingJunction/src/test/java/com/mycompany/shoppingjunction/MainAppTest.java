/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.shoppingjunction;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import ShoppingPackage.ProductCatalog;
import ShoppingPackage.ShoppingCart;
import ShoppingPackage.SellerFrame;
import ShoppingPackage.CustomerFrame;
import ShoppingPackage.LoginStrategy;
import ShoppingPackage.AuthenticationManager;
import ShoppingPackage.SimpleAuthStrategy;
import ShoppingPackage.LoginListener;
import ShoppingPackage.LoginFrame;

public class MainAppTest {

    private AuthenticationManager authManager;
    private ProductCatalog sharedProductCatalog;
    private ShoppingCart customerShoppingCart;

    @BeforeAll
    public static void setUpClass() {
        System.out.println("Starting tests for MainApp...");
    }

    @AfterAll
    public static void tearDownClass() {
        System.out.println("Finished tests for MainApp.");
    }

    @BeforeEach
    public void setUp() {
        // Initialize the shared instances required for testing
        sharedProductCatalog = new ProductCatalog();
        customerShoppingCart = new ShoppingCart();
        LoginStrategy authStrategy = new SimpleAuthStrategy();
        authManager = new AuthenticationManager(authStrategy);
    }

    @AfterEach
    public void tearDown() {
        sharedProductCatalog = null;
        customerShoppingCart = null;
        authManager = null;
    }

    @Test
    public void testMainSuccessScenario() {
        System.out.println("Testing main method success scenario...");

        // Mock login success behavior
        LoginListener loginListener = new LoginListener() {
            @Override
            public void onLoginSuccess() {
                System.out.println("Login successful in test.");
                // Verify that the catalog and cart are initialized correctly
                assertNotNull(sharedProductCatalog);
                assertNotNull(customerShoppingCart);

                // Simulate frame creation
                SellerFrame sellerFrame = new SellerFrame(sharedProductCatalog);
                CustomerFrame customerFrame = new CustomerFrame(sharedProductCatalog, customerShoppingCart);

                assertNotNull(sellerFrame);
                assertNotNull(customerFrame);

                // Assert frames are visible (you may need to mock visibility for a real GUI test)
                sellerFrame.setVisible(true);
                customerFrame.setVisible(true);
                assertTrue(sellerFrame.isVisible());
                assertTrue(customerFrame.isVisible());
            }

            @Override
            public void onLoginFailure() {
                fail("Login should succeed in this test case.");
            }
        };

        // Simulate login frame behavior
        LoginFrame loginFrame = new LoginFrame(authManager, loginListener);
        loginFrame.setVisible(true);
        assertTrue(loginFrame.isVisible());
    }

    @Test
    public void testMainFailureScenario() {
        System.out.println("Testing main method failure scenario...");

        // Mock login failure behavior
        LoginListener loginListener = new LoginListener() {
            @Override
            public void onLoginSuccess() {
                fail("Login should fail in this test case.");
            }

            @Override
            public void onLoginFailure() {
                System.out.println("Login failed as expected in test.");
                // Verify appropriate failure handling
            }
        };

        // Simulate login frame behavior
        LoginFrame loginFrame = new LoginFrame(authManager, loginListener);
        loginFrame.setVisible(true);
        assertTrue(loginFrame.isVisible());
    }
}
